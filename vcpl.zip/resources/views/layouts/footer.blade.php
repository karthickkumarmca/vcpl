<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    <strong><span>&copy; {!! date('Y') !!} Powered by MRS Chains. All rights reserved.</span></strong>
</footer>
