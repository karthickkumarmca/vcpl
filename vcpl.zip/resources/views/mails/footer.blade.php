<tr style="background:#EEEEEE;">
	<td align="center" style="padding: 30px 0px 20px;"> 
		<img src="{{$message->embed(public_path('images/email_template/event.png'))}}" alt=" event">
		<p style="font-size: 18px;color:#369F21; font-weight: 500; padding-bottom: 0px; margin-bottom:5px;">Join the Movement.</p>
	</td>
</tr>

</tbody>
</table>

</body>
</html>