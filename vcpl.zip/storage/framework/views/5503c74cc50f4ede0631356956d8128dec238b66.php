
<?php $__env->startSection('content'); ?>
<style>
	.error{color:#f00;    margin-bottom: 0px;}
</style>
<section class="content-header">
	<h1 class="col-lg-6 no-padding">Sub Categories <small>Management</small></h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url(route('home'))); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="<?php echo e(url(route('categories-list'))); ?>">Sub Categories management</a></li>
		<li>Create Sub Categories</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<form id="admin-form" method="post" enctype="multipart/form-data" action="<?php echo e(URL::to('sub-categories/store')); ?>">
				<?php echo csrf_field(); ?>
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Create Sub Categories</h3>
					</div>

					<div class="box-body">
						<div class="col-md-12">
							<div class="form-group">
								<label>Name <span class="text-danger"> *</span></label>
								<input type="text" class="form-control pos_validate" autocomplete="off" placeholder="Enter categories" name="sub_category_name" value="<?php echo e(old('sub_category_name')); ?>" data-rule="admin" minlength="3" maxlength="128"/>
								<span class="validation_error"></span>
								<?php if($errors->has('sub_category_name')): ?>
								<div class="error"><?php echo e($errors->first('sub_category_name')); ?></div>
								<?php endif; ?>
							</div>
						</div>
						
					</div>
					<div class="box-footer">
						<div class="pull-right">
							<button type="submit" id="categories-submit" class="btn btn-success">
								Save
							</button>
							<a href="<?php echo e(url(route('sub-categories-list'))); ?>" class="btn btn-default">
								Back
							</a>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after-scripts-end'); ?>
<script src="<?php echo e(asset('js/custom/formValidation.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/additional-methods.min.js')); ?>"></script>

    <?php echo $__env->make('master.sub_categories.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vcpl\vcpl\resources\views/master/sub_categories/create.blade.php ENDPATH**/ ?>