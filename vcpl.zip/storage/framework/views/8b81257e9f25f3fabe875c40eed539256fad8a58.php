<table border=1 cellspacing=0 cellpadding=3>
    <tbody>
        <tr>
            <th>URL</th>
            <td><?= $url ?></td>
        </tr>
        <tr>
            <th>Method</th>
            <td><?= $method ?></td>
        </tr>
        <tr>
            <th>headers</th>
            <td><?= $headers ?></td>
        </tr>
        <tr>
            <th>user</th>
            <td><?= $user ?></td>
        </tr>
        <tr>
            <th>inputs</th>
            <td><?= $inputs ?></td>
        </tr>
        <tr>
            <th>message</th>
            <td><?= $error_message ?></td>
        </tr>
        <tr>
            <th>error_category</th>
            <td><?= $error_category ?></td>
        </tr>
        <tr>
            <th>trace</th>
            <td>
                <?php $__currentLoopData = $trace; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php print_r($value) ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\vcpl\vcpl\resources\views/mails/error.blade.php ENDPATH**/ ?>