<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    <strong><span>&copy; <?php echo date('Y'); ?> Powered by MRS Chains. All rights reserved.</span></strong>
</footer>
<?php /**PATH D:\xampp\htdocs\vcpl\vcpl\resources\views/layouts/footer.blade.php ENDPATH**/ ?>