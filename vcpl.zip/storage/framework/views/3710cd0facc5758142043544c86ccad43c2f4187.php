<header class="main-header">
    <style>
        .skin-red .sidebar-menu>li.active>a {
            border-left-color: #007847;
        }

        .sidebar-menu>li>a:hover {
            background-color: #007847 !important;
        }

        .skin-red .main-header .navbar .sidebar-toggle:hover {
            background-color: #000000;
        }
    </style>

    <a href="<?php echo e(url('/')); ?>" class="logo" style="height: 55px;padding: 0 5px!important;background-color: #fff;">
        <img src="<?php echo e(asset('images/logonew.png')); ?>" alt="Logo" style="max-width:100%;">
       
    </a>
    <nav class="navbar navbar-expand-md fixed-top flex-md-nowrap p-0" style="background-color: #007847;">
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <div class="collapse navbar-collapse">
            <div class="navbar-nav mr-auto">
            </div>
            <ul class="navbar-nav mt-2 mt-md-0 nav">

                <li class="user user-menu">
                    <a href="<?php echo e(url('change-user-password')); ?>">Change Password</a>
                </li>
                <li>
                    <a title="Logout" data-toggle="control-sidebar" href="#" onclick="event.preventDefault();
                    swal('Are you sure want to logout?','','',{
                        buttons:{						
                            cancel : 'Cancel',
                            confirm : {text:'Confirm',className:'btn-success'}
                        }	
                    })
                    .then((value) => {
                        if(value){
                            document.getElementById('logout-form').submit();
                        }
                    });
                    ">
                        <i class="fa fa-sign-out fa-fw"></i>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </nav>

    


</header>
<script src="<?php echo e(URL('js/jquery.min.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\vcpl\vcpl\resources\views/layouts/header.blade.php ENDPATH**/ ?>