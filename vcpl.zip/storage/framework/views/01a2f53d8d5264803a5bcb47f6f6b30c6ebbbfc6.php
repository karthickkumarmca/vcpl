
<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1 class="col-lg-6 no-padding">
		Units <small>management</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url(route('home'))); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="<?php echo e(url(route('units-list'))); ?>">Units management</a></li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-primary">
				<div class="box-header with-border">
					<h3 class="box-title">Units Details</h3>
				</div>
				<div class="box-body">
					<?php if($units->status): ?>
					<?php
					$status = "Active";
					$status_bg="bg-green";
					?>
					<?php else: ?>
					<?php
					$status = "In-Active";
					$status_bg="bg-red";
					?>
					<?php endif; ?>
					<div class="table-responsive">
						<table class="table table-bordered">
							<tr>
								<th class="grey_header">
									<label>Unit Name</label>
								</th>
								<td><?php echo $units->unit_name; ?></td>
							</tr>
							<tr>
								<th class="grey_header">
									<label>Status</label>
								</th>
								<td><span class="badge <?php echo $status_bg; ?>"> <?php echo $status; ?></span></td>
							</tr>
							
							<tr>
								<th class="grey_header">
									<label>Created At</label>
								</th>
								<td><?php echo $units->created_at; ?></td>
							</tr>
						</table>
					</div>
				</div>
				<div class="box-footer">
					<div class="pull-right">
						<a href="<?php echo url('units-list'); ?>" class="btn btn-default">
							<strong>Back</strong>
						</a>
					</div>
				</div>

			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vcpl\vcpl\resources\views/units/view.blade.php ENDPATH**/ ?>