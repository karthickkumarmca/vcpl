<?php

/**
 * User Roles
 */

return [
	'super_admin'              			=> 1,
	'admin'                    			=> 2,
	'customer'                			=> 3,
];
