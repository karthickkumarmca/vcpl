<?php 

/**
 * Used to hold the user type integer values
 */

return [
	'httpSuccessCode'           => 200,
	'httpFailureCode'         	=> 400,
	'httpAuthInvalidCode'    	=> 401,
	'httpCreatedCode'          	=> 201,
];