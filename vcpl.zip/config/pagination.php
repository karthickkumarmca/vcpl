<?php

/**
 * Pagination
 */

return [
	'page'       		=> 1,
	'offset'  			=> 10
];