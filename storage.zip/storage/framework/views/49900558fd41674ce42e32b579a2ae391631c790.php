<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(env('APP_NAME')); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <!-- <link rel="icon" href="<?php echo e(asset('images/fav-icon.png')); ?>" type="image/png" sizes="32x32"> -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/bootstrap-datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/AdminLTE.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/_all-skins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/skin-blue.min.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link rel="stylesheet" href="<?php echo e(URL('css/custom/dataTable.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/custom/formValidation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/custom/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL('css/plugins/multiselect/jquery.multiselect.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="hold-transition skin-red sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.sidebar-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
            <div class="corona-preloader-backdrop">
                <div class="corona-page-preloader">Loading...</div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <script src="<?php echo e(URL('js/jquery.validate.min.js')); ?>"></script>   
    <?php echo $__env->yieldContent('before-scripts-end'); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo $__env->yieldContent('after-scripts-end'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\mrs_chains\resources\views/layouts/main.blade.php ENDPATH**/ ?>