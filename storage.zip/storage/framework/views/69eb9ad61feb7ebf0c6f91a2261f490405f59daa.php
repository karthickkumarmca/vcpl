
<?php $__env->startSection('content'); ?>
<style>
	.error{color:#f00;    margin-bottom: 0px;}
</style>
<section class="content-header">
	<h1 class="col-lg-6 no-padding">Chain <small>Management</small></h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url(route('home'))); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="<?php echo e(url(route('chain-list'))); ?>">Chain Management</a></li>
		<li>Create Chain</li>
	</ol>
</section>

<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<form id="admin-form" method="post" enctype="multipart/form-data" action="<?php echo e(URL::to('chain/store')); ?>">
				<?php echo csrf_field(); ?>
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Create Chain</h3>
					</div>

					<div class="box-body">
						<div class="col-md-12">
							<div class="form-group">
								<label>Chain Type <span class="text-danger"> *</span></label>
								<input type="text" class="form-control pos_validate" autocomplete="off" placeholder="Enter Chain Type" name="chain" value="<?php echo e(old('chain')); ?>" data-rule="admin" minlength="3" maxlength="128"/>
								<span class="validation_error"></span>
								<?php if($errors->has('chain')): ?>
								<div class="error"><?php echo e($errors->first('chain')); ?></div>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Select Hallmark <span class="text-danger"> *</span></label>
								<select name="hallmark_id" class="form-control pos_validate" id="hallmark_id">
									<option value="">Select Hallmark</option>
									<?php if(isset($hallmarks)): ?>
										<?php $__currentLoopData = $hallmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hallmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($hallmark['id']); ?>"><?php echo e($hallmark['rate']); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
								<span class="validation_error"></span>
								<?php if($errors->has('hallmark_id')): ?>
								<div class="error"><?php echo e($errors->first('hallmark_id')); ?></div>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group has-feedback <?php if($errors->has('g-recaptcha-response')): ?> has-error <?php endif; ?> col-md-12" id="recaptcha-boxs" style="max-width:100%;height: 0px !important;">
								<div id="capcha-elements"></div>
								<span class="validation_error"></span>
								<?php if($errors->has('g-recaptcha-response')): ?>
								<div class="error"><?php echo e($errors->first('g-recaptcha-response')); ?></div>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="box-footer">
						<div class="pull-right">
							<button type="submit" id="chain-submit" class="btn btn-success">
								Save
							</button>
							<a href="<?php echo e(url(route('chain-list'))); ?>" class="btn btn-default">
								Back
							</a>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after-scripts-end'); ?>
<script src="<?php echo e(asset('js/custom/formValidation.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/additional-methods.min.js')); ?>"></script>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script type="text/javascript">
	var siteCaptchaKey = "<?php echo e(config('general_settings.site_captcha_key')); ?>";
	var onloadCallback = function() {
		grecaptcha.render('capcha-elements', {
			'sitekey': siteCaptchaKey
		});
	};
</script>
<script>
	function scaleCaptcha() {
            // Width of the reCAPTCHA element, in pixels
            var reCaptchaWidth = 304;
            var reCaptchaheight = 78;

            // Get the containing element's width
            var containerWidth = $('#recaptcha-box').width();

            if (reCaptchaWidth != containerWidth) {
                // Calculate the scale
                var captchaScale = containerWidth / reCaptchaWidth;
                // Apply the transformation
                $('#capcha-element').css({
                	'transform': 'scale(0)'
                });
                $('#capcha-element').css({
                	'-webkit-transform': 'scale(' + captchaScale + ')'
                });
                $('#capcha-element').css({
                	'transform-origin': '0 0'
                });
                $('#capcha-element').css({
                	'-webkit-transform-origin': '0 0'
                });

                $('#recaptcha-box').height(reCaptchaheight * captchaScale);
            }
        }
        $(window).resize(function() {
        	scaleCaptcha();
        });
        scaleCaptcha();
    </script>
    <?php echo $__env->make('chains.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mrschains\resources\views/chains/create.blade.php ENDPATH**/ ?>