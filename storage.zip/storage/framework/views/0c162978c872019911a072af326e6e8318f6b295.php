
<?php $__env->startSection('content'); ?>
<style>
	.error{color:#f00;    margin-bottom: 0px;}
</style>
<section class="content-header">
	<h1 class="col-lg-6 no-padding">
		Customer <small>Management</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url(route('home'))); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="<?php echo e(url(route('customer-list'))); ?>">Customer management</a></li>
		<li>Edit Customer</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<form id="admin-form" method="post" enctype="multipart/form-data" action="<?php echo e(URL::to('customer/store')); ?>">
				<?php echo csrf_field(); ?>
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Edit Customer</h3>
					</div>

					<div class="box-body">
						<div class="col-md-12">
							<div class="form-group">
								<label>Name <span class="text-danger"> *</span></label>
								<input type="text" class="form-control pos_validate" placeholder="Enter Name" name="name" value="<?php echo e(old('name') ? old('name') : $customer->name); ?>" data-rule="admin" onkeypress="return ((event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || event.charCode == 8 || event.charCode == 32);" maxlength="128"/>
								<span class="validation_error"></span>
								<?php if($errors->has('name')): ?>
								<div class="error"><?php echo e($errors->first('name')); ?></div>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Email <span class="text-danger"> *</span></label>
								<input type="text" class="form-control pos_validate allow_characters" placeholder="Enter Email" name="email" value="<?php echo e(old('email') ? old('email') : $customer->email); ?>" data-rule="admin" />
								<input type="hidden" name="old_email" id="old_email" value="<?php echo e($customer->email); ?>">
								<span class="validation_error"></span>
								<?php if($errors->has('email')): ?>
								<div class="error"><?php echo e($errors->first('email')); ?></div>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Phone Number <span class="text-danger"> *</span></label>
								<input type="text" class="form-control pos_validate number_restrict" placeholder="Enter Phone Number" name="phone" value="<?php echo e(old('phone') ? old('phone') : $customer->phonenumber); ?>" data-rule="admin" onkeypress="return ((event.charCode >= 48 && event.charCode <= 57));" maxlength="10"/>
								<input type="hidden" name="old_phone" id="old_phone" value="<?php echo e($customer->phonenumber); ?>">
								<span class="validation_error"></span>
								<?php if($errors->has('phone')): ?>
								<div class="error"><?php echo e($errors->first('phone')); ?></div>
								<?php endif; ?>
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="form-group has-feedback <?php if($errors->has('g-recaptcha-response')): ?> has-error <?php endif; ?> col-md-12" id="recaptcha-boxs" style="max-width:100%;height: 0px !important;">
								<div id="capcha-elements"></div>
								<span class="validation_error"></span>
								<?php if($errors->has('g-recaptcha-response')): ?>
								<div class="error"><?php echo e($errors->first('g-recaptcha-response')); ?></div>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="box-footer">
						<input type="hidden" name="edited_customer" id="edited_customer" value="1">
						<div class="pull-right">
							<button type="submit" id="customer-submit" class="btn btn-success">
								<strong>Save</strong>
							</button>
							<a href="<?php echo url(route('customer-list')); ?>" class="btn btn-default">
								<strong>Back</strong>
							</a>
						</div>
					</div>
				</div>
				<input type="hidden" name="customer_id" value="<?php echo $customer->uuid; ?>" />
			</form>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after-scripts-end'); ?>
<script src="<?php echo e(asset('js/custom/formValidation.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-validation/additional-methods.min.js')); ?>"></script>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script type="text/javascript">
	var siteCaptchaKey = "<?php echo e(config('general_settings.site_captcha_key')); ?>";
	var onloadCallback = function() {
		grecaptcha.render('capcha-elements', {
			'sitekey': siteCaptchaKey
		});
	};
</script>

<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrs_chains\resources\views/customers/edit.blade.php ENDPATH**/ ?>