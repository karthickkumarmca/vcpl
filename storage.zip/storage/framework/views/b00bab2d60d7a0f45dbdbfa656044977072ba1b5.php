<aside class="main-sidebar elevation-4 sidebar-dark-success" style="padding-top: 50px;">
	<section class="sidebar">
		<ul class="sidebar-menu" data-widget="tree">
			<?php if(config("roles.".Session::get('user_role').".dashboard")): ?>
			<li class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
				<a href="<?php echo url('dashboard'); ?>">
					<i class="fa fa-dashboard"></i> <span>Dashboard </span>
				</a>
			</li>
			<?php endif; ?>
			<?php if(config("roles.".Session::get('user_role').".hallmark_management")): ?>
			<li class="<?php echo e(Request::is('hallmark-list') ? 'active' : ''); ?> <?php echo e(Request::is('create-hallmark') ? 'active' : ''); ?> <?php echo e(Request::is('edit-hallmark/*') ? 'active' : ''); ?> <?php echo e(Request::is('view-hallmark/*') ? 'active' : ''); ?>">
				<a href="<?php echo url(route('hallmark-list')); ?>">
					<i class="fa fa-calendar"></i> <span>Hallmark Management</span>
				</a>
			</li>
			<?php endif; ?>
			<?php if(config("roles.".Session::get('user_role').".user_management")): ?>
			<li class="<?php echo e(Request::is('user-list') ? 'active' : ''); ?> <?php echo e(Request::is('create-user') ? 'active' : ''); ?> <?php echo e(Request::is('edit-user/*') ? 'active' : ''); ?> <?php echo e(Request::is('view-user/*') ? 'active' : ''); ?> <?php echo e(Request::is('change-password/*') ? 'active' : ''); ?>">
				<a href="<?php echo url(route('user-list')); ?>">
					<i class="fa fa-user"></i> <span>Users </span>
				</a>
			</li>
			<?php endif; ?>
			<?php if(config("roles.".Session::get('user_role').".customer_management")): ?>
			<li class="<?php echo e(Request::is('customer-list') ? 'active' : ''); ?> <?php echo e(Request::is('create-customer') ? 'active' : ''); ?> <?php echo e(Request::is('edit-customer/*') ? 'active' : ''); ?> <?php echo e(Request::is('view-customer/*') ? 'active' : ''); ?>">
				<a href="<?php echo url(route('customer-list')); ?>">
					<i class="fa fa-users"></i> <span>Customers </span>
				</a>
			</li>
			<?php endif; ?>
			<?php if(config("roles.".Session::get('user_role').".stock_management")): ?>
			<li class="<?php echo e(Request::is('stock-list') ? 'active' : ''); ?> <?php echo e(Request::is('create-stock') ? 'active' : ''); ?> <?php echo e(Request::is('edit-stock/*') ? 'active' : ''); ?> <?php echo e(Request::is('view-stock/*') ? 'active' : ''); ?>">
				<a href="<?php echo url(route('stock-list')); ?>">
					<i class="fa fa-stack-exchange"></i> <span>Stock Order </span>
				</a>
			</li>
			<?php endif; ?>
			<li>
				<a title="Logout" data-toggle="control-sidebar" href="#" onclick="event.preventDefault();
				swal('Are you sure want to logout?','','',{
					buttons:{						
						cancel : 'Cancel',
						confirm : {text:'Confirm',className:'btn-success'}
					}	
				})
				.then((value) => {
					if(value){
						document.getElementById('logout-form-slide').submit();
					}
				});
				">
				<i class="fa fa-sign-out fa-fw"></i> Logout
				</a>
				<form id="logout-form-slide" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
					<?php echo csrf_field(); ?>
				</form>
			</li>
		</ul>
	</section>
</aside><?php /**PATH C:\xampp\htdocs\mrs_chains\resources\views/layouts/sidebar-menu.blade.php ENDPATH**/ ?>